import java.io.*;
import java.util.*;
import java.util.regex.*;

class Token {
    String type;
    String value;
    int line;

    Token(String type, String value, int line) {
        this.type = type;
        this.value = value;
        this.line = line;
    }

    @Override
    public String toString() {
        return String.format("Line %d: <%s, %s>", line, type, value);
    }
}

public class Main {
    private static final Map<String, String> KEYWORDS = new HashMap<String, String>();
    private static final Map<String, String> SYMBOLS = new HashMap<String, String>();

    static {
        KEYWORDS.put("bool", "T_Bool");
        KEYWORDS.put("break", "T_Break");
        KEYWORDS.put("continue", "T_Continue");
        KEYWORDS.put("else", "T_Else");
        KEYWORDS.put("false", "T_False");
        KEYWORDS.put("fn", "T_Fn");
        KEYWORDS.put("i32", "T_Int");
        KEYWORDS.put("if", "T_If");
        KEYWORDS.put("let".trim(), "T_Let");
        KEYWORDS.put("loop", "T_Loop");
        KEYWORDS.put("mut", "T_Mut");
        KEYWORDS.put("println!", "T_Print");
        KEYWORDS.put("return", "T_Return");
        KEYWORDS.put("true", "T_True");


        SYMBOLS.put("+", "T_AOp_Trust");
        SYMBOLS.put("-", "T_AOp_MN");
        SYMBOLS.put("*", "T_AOp_ML");
        SYMBOLS.put("/", "T_AOp_DV");
        SYMBOLS.put("%", "T_AOp_RM");

        SYMBOLS.put("<", "T_ROp_L");
        SYMBOLS.put(">", "T_ROp_G");
        SYMBOLS.put("<=", "T_ROp_LE");
        SYMBOLS.put(">=", "T_ROp_GE");
        SYMBOLS.put("!=", "T_ROp_NE");
        SYMBOLS.put("==", "T_ROp_E");

        SYMBOLS.put("&&", "T_LOp_AND");
        SYMBOLS.put("||", "T_LOp_OR");
        SYMBOLS.put("!", "T_LOp_NOT");

        SYMBOLS.put("=", "T_Assign");
        SYMBOLS.put(":", "T_Colon");
        SYMBOLS.put("->", "T_Arrow");
        SYMBOLS.put("=>", "T_ArrowAssign");


        SYMBOLS.put("(", "T_LP");
        SYMBOLS.put(")", "T_RP");
        SYMBOLS.put("{", "T_LC");
        SYMBOLS.put("}", "T_RC");
        SYMBOLS.put("[", "T_LB");
        SYMBOLS.put("]", "T_RB");
        SYMBOLS.put(";", "T_Semicolon");
        SYMBOLS.put(",", "T_Comma");

    }

    private static final Pattern TOKEN_REGEX = Pattern.compile(
            "([ \t\r]+)|" +                             // group 1: WHITESPACE
                    "(\\n)|" +                                  // group 2: NEWLINE
                    "(//.*)|" +                                 // group 3: COMMENT
                    "(\"(?:\\\\.|[^\"\\\\])*\")|" +             // group 4: STRING (بدون گروه داخلی)
                    "(0x[0-9a-fA-F]+)|" +                       // group 5: HEX
                    "(\\d+)|" +                                 // group 6: DECIMAL
                    "([a-zA-Z_][a-zA-Z0-9_!]*)|" +              // group 7: ID
                    "(==|!=|<=|>=|&&|\\|\\||->|[+\\-*/%<>=!&|:;.,{}\\[\\]()])" // group 8: SYMBOL
    );


    public static List<Token> tokenize(String input) {
        List<Token> tokens = new ArrayList<Token>();
        String[] lines = input.split("\n");
        int lineNum = 1;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            Matcher matcher = TOKEN_REGEX.matcher(line);
            int index = 0;

            while (matcher.find()) {
                if (matcher.start() != index) {
                    System.err.println("khataye tahlil dar khate " + lineNum + " : charecter na motabar : " + line.substring(index, matcher.start()));
                    index = matcher.start();
                }

                if (matcher.group(1) != null || matcher.group(3) != null) {
                    // نادیده گرفتن WHITESPACE یا COMMENT
                } else if (matcher.group(2) != null) {
                    // NEWLINE → نادیده گرفته می‌شود
                } else if (matcher.group(4) != null) {
                    tokens.add(new Token("T_String", matcher.group(4), lineNum));
                } else if (matcher.group(5) != null) {
                    tokens.add(new Token("T_Hexadecimal", matcher.group(5), lineNum));
                } else if (matcher.group(6) != null) {
                    tokens.add(new Token("T_Decimal", matcher.group(6), lineNum));
                }

                // group(7): ID
                else if (matcher.group(7) != null) {
                    String id = matcher.group(7).trim();
                    if (KEYWORDS.containsKey(id)) {
                        tokens.add(new Token(KEYWORDS.get(id), id, lineNum));
                    } else {
                        tokens.add(new Token("T_Id", id, lineNum));
                    }
                }
                // group(8): SYMBOL
                else if (matcher.group(8) != null) {
                    String symbol = matcher.group(8);
                    String tokenName = SYMBOLS.get(symbol);
                    if (tokenName == null) tokenName = "T_Unknown";
                    tokens.add(new Token(tokenName, symbol, lineNum));
                }


                index = matcher.end();
            }

            lineNum++;
            if (lineNum == 7) {
                int xxx = 0;
            }
        }
        return tokens;
    }

    public static void main(String[] args) throws IOException {
        String path = "I:/all projects/untitled3/test.trust";  // مسیر فایل ورودی

        File file = new File(path);
        if (!file.exists()) {
            System.err.println("خطا: فایل \"" + path + "\" یافت نشد.");
            return;
        }

        StringBuilder builder = new StringBuilder();
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), "UTF-8")  // حل مشکل علامت سوال
        );
        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line).append("\n");
        }
        reader.close();

        String code = builder.toString();
        List<Token> tokens = tokenize(code);

        for (Token token : tokens) {
            System.out.println(token);
        }

    }
}
