import java.io.*;
import java.util.*;
import java.util.regex.*;

class Token {
    String type;
    String value;
    int line;

    Token(String type, String value, int line) {
        this.type = type;
        this.value = value;
        this.line = line;
    }

    @Override
    public String toString() {
        return String.format("Line %d: <%s, %s>", line, type, value);
    }
}

class Node {
    String label;
    String value;
    List<Node> children = new ArrayList<Node>();

    Node(String label) {
        this.label = label;
    }

    Node(String label, String value) {
        this.label = label;
        this.value = value;
    }

    void add(Node child) {
        children.add(child);
    }
}

class TreePrinter {
    static void print(Node node, String prefix, boolean isLast) {
        System.out.print(prefix);
        System.out.print(isLast ? "|-- " : "||-- ");
        System.out.print(node.value != null ? node.label + ": '" + node.value + "'" : node.label);
        System.out.println();
        for (int i = 0; i < node.children.size(); i++) {
            print(node.children.get(i), prefix + (isLast ? "    " : "|   "), i == node.children.size() - 1);
        }
    }
}

class Parser {

    List<Token> tokens;

    ArrayList<String> errors = new ArrayList<String>();

    int pos = 0;

    Parser(List<Token> tokens) {
        for (int cou = 0; cou < tokens.size(); cou++) {
            if (tokens.get(cou).type == "T_Comment") {
                tokens.remove(cou);
            }
        }
        this.tokens = tokens;
    }

    Token peek() {
        return pos < tokens.size() ? tokens.get(pos) : new Token("EOF", "", -1);
    }

    boolean check(String type) {
        return peek().type.equals(type);
    }

    Token consume(String type) {
        if (!check(type)) {
            error("Expected " + type + ", got " + peek().type);
            // return dummy to allow continuation
            return new Token(type, "(missing)", peek().line);
        }
        return tokens.get(pos++);
    }

    void error(String msg) {
        Token t = peek();
        errors.add(String.format("Syntax error at line %d: %s (found '%s')",
                t.line, msg, t.type));
        synchronize();
    }
    // advance until a statement boundary
    void synchronize() {
        // skip current token
        if (!peek().type.equals("EOF")) pos++;
        // skip until next semicolon or EOF
        while (pos < tokens.size()) {
            if (peek().type.equals("T_Semicolon") || peek().type.equals("EOF")) {
                // consume the semicolon to move past the boundary
                if (peek().type.equals("T_Semicolon")) pos++;
                return;
            }
            pos++;
        }
    }


    Node parseProgram() {
        Node root = new Node("program");
        while (!check("EOF")) {
            root.add(parseItem());
        }
        if (errors.size()!=0) {
            System.err.println("Errors Found:");
            for (int er=0;er<errors.size();er++){
                System.out.println(errors.get(er));
            }
        }
        return root;
    }

    // آیتم -> تابع | دستور
    Node parseItem() {
        try {
            if (check("T_Fn")) return parseFunction();
            else return parseStatement();
        } catch (Exception ex) {
            // ثبت خطا و بازیابی
            error("Error parsing item: " + ex.getMessage());
            // بعد از بازیابی، یک گره خطا اضافه کن و ادامه بده
            return new Node("error");
        }
    }

    // تابع -> fn id ( params ) (-> type)? block
    Node parseFunction() {
        Node fn = new Node("function");
        // توکن fn
        Token fnTok = consume("T_Fn");
        fn.add(new Node(fnTok.type, fnTok.value));
        // شناسه تابع
        Token id = consume("T_Id");
        fn.add(new Node(id.type, id.value));
        // پرانتز باز
        Token lp = consume("T_LP");
        fn.add(new Node(lp.type, lp.value));
        // پارامترها
        fn.add(parseParams());
        // پرانتز بسته
        Token rp = consume("T_RP");
        fn.add(new Node(rp.type, rp.value));
        // نوع برگشتی (اختیاری)
        if (check("T_Arrow")) {
            Token arrow = consume("T_Arrow");
            fn.add(new Node(arrow.type, arrow.value));
            // اگر نوع معمولی بود
            if (check("T_Int") || check("T_Bool") || check("T_Id")) {
                Token rt = consume(peek().type);
                fn.add(new Node(rt.type, rt.value));
            }
            // اگر شروع آرایه بود: [i32;5]
            else if (check("T_LB")) {
                Node retArrType = new Node("return_array_type");
                Token lb = consume("T_LB");
                retArrType.add(new Node(lb.type, lb.value));
                Token t = consume(peek().type);
                retArrType.add(new Node(t.type, t.value));
                consume("T_Semicolon");
                Token len = consume("T_Decimal");
                retArrType.add(new Node(len.type, len.value));
                Token rb = consume("T_RB");
                retArrType.add(new Node(rb.type, rb.value));
                fn.add(retArrType);
            }
        }

        // آکولاد باز بلوک
        Token lc = consume("T_LC");
        fn.add(new Node(lc.type, lc.value));
        // محتویات بلوک
        Node block = new Node("block");
        while (!check("T_RC")) {
            block.add(parseStatement());
        }
        fn.add(block);
        // آکولاد بسته بلوک
        Token rc = consume("T_RC");
        fn.add(new Node(rc.type, rc.value));
        return fn;
    }

    // پارامترها -> (id(: type)? (, id(: type)? )*)?
    Node parseParams() {
        Node params = new Node("params");
        if (!check("T_RP")) {
            do {
                Token id = consume("T_Id");
                Node p = new Node("param");
                p.add(new Node("T_Id", id.value));
                if (check("T_Colon")) {
                    consume("T_Colon");
                    Token t = consume(peek().type);
                    p.add(new Node("type", t.value));
                }
                params.add(p);
            } while (check("T_Comma") && consume("T_Comma") != null);
        }
        return params;
    }

    // بلوک -> { stmt* }
    Node parseBlock() {
        Node block = new Node("block");
        consume("T_LC");
        while (!check("T_RC")) block.add(parseStatement());
        consume("T_RC");
        return block;
    }

    // دستور -> let | if | loop | return | println | expr;
    Node parseStatement() {
        if (check("T_Let")) return parseLet();
        if (check("T_If")) return parseIf();
        if (check("T_Loop")) return parseLoop();
        if (check("T_Return")) return parseReturn();
        if (check("T_Print")) return parsePrint();
        if (check("T_Break")) {
            Token b = consume("T_Break");
            consume("T_Semicolon");
            return new Node(b.type, b.value);
        }
        if (check("T_Continue")) {
            Token c = consume("T_Continue");
            consume("T_Semicolon");
            return new Node(c.type, c.value);
        }

        Node expr = parseExpression();
        consume("T_Semicolon");
        Node stmt = new Node("expr_stmt");
        stmt.add(expr);
        return stmt;
    }

    Node parseLet() {
        Token letTok = consume("T_Let");
        Node letNode = new Node("let");
        letNode.add(new Node(letTok.type, letTok.value));
        // optional mut
        if (check("T_Mut")) {
            Token mutTok = consume("T_Mut");
            letNode.add(new Node(mutTok.type, mutTok.value));
        }
        // pattern: tuple, array or identifier
        Node pattern;
        if (check("T_LP")) {
            // tuple pattern
            pattern = new Node("tuple_pattern");
            consume("T_LP");
            do {
                Token id = consume("T_Id");
                pattern.add(new Node(id.type, id.value));
            } while (check("T_Comma") && consume("T_Comma") != null);
            consume("T_RP");
            letNode.add(pattern);
            // optional type annotation for tuple
            if (check("T_Colon")) {
                consume("T_Colon");
                Node tupleType = new Node("tuple_type");
                consume("T_LP");
                do {
                    Token t = consume(peek().type);
                    tupleType.add(new Node(t.type, t.value));
                } while (check("T_Comma") && consume("T_Comma") != null);
                consume("T_RP");
                letNode.add(tupleType);
            }
        } else if (check("T_LB")) {
            // array pattern
            pattern = new Node("array_pattern");
            Token lb = consume("T_LB");
            pattern.add(new Node(lb.type, lb.value));
            Token t = consume(peek().type);
            pattern.add(new Node(t.type, t.value));
            consume("T_Semicolon");
            Token len = consume("T_Decimal");
            pattern.add(new Node(len.type, len.value));
            Token rb = consume("T_RB");
            pattern.add(new Node(rb.type, rb.value));
            letNode.add(pattern);
        } else {
            Token id = consume("T_Id");
            pattern = new Node(id.type, id.value);
            letNode.add(pattern);
        }
        // optional type annotation for identifier or array
        if (check("T_Colon")) {
            consume("T_Colon");
            if (check("T_LB")) {
                Node typeArr = new Node("array_type");
                Token lb2 = consume("T_LB");
                typeArr.add(new Node(lb2.type, lb2.value));
                Token tt = consume(peek().type);
                typeArr.add(new Node(tt.type, tt.value));
                consume("T_Semicolon");
                Token l2 = consume("T_Decimal");
                typeArr.add(new Node(l2.type, l2.value));
                Token rb2 = consume("T_RB");
                typeArr.add(new Node(rb2.type, rb2.value));
                letNode.add(typeArr);
            } else {
                // simple type
                Token tt = consume(peek().type);
                letNode.add(new Node(tt.type, tt.value));
            }
        }
        // optional assignment
        if (check("T_Assign")) {
            consume("T_Assign");
            if (pattern.label.equals("tuple_pattern")) {
                // tuple literal
                Node tplLit = new Node("tuple_literal");
                consume("T_LP");
                do {
                    tplLit.add(parseExpression());
                } while (check("T_Comma") && consume("T_Comma") != null);
                consume("T_RP");
                letNode.add(tplLit);
            } else if (check("T_LB")) {
                // array literal
                Node arrLit = new Node("array_literal");
                consume("T_LB");
                do {
                    arrLit.add(parseExpression());
                } while (check("T_Comma") && consume("T_Comma") != null);
                consume("T_RB");
                letNode.add(arrLit);
            } else {
                letNode.add(parseExpression());
            }
        }
        Token semi = consume("T_Semicolon");
        letNode.add(new Node(semi.type, semi.value));
        return letNode;
    }

    Node parseIf() {
        Node iff = new Node("if");
        consume("T_If");
        iff.add(parseExpression());
        iff.add(parseBlock());
        while (check("T_Else")) {
            consume("T_Else");
            if (check("T_If")) {
                Node elseif = parseIf(); // بازگشتی
                iff.add(elseif);
            } else {
                Node elseBlock = parseBlock();
                iff.add(elseBlock);
                break;
            }
        }
        return iff;

    }

    Node parseLoop() {
        Node loop = new Node("loop");
        consume("T_Loop");
        loop.add(parseBlock());
        return loop;
    }

    Node parseReturn() {
        Node ret = new Node("return");
        consume("T_Return");
        ret.add(parseExpression());
        consume("T_Semicolon");
        return ret;
    }

    Node parsePrint() {

        Node pr = new Node("println");
        Token prt = consume("T_Print");
        pr.add(new Node(prt.type, prt.value));
        Token lp = consume("T_LP");
        pr.add(new Node(lp.type, lp.value));

        // خواندن قالب تا ')'
        while (!check("T_RP")) {
            if (check("T_String")) {
                Token str = consume("T_String");
                pr.add(new Node(str.type, str.value));
            } else if (check("T_Comma")) {
                Token c = consume("T_Comma");
                pr.add(new Node(c.type, c.value));
            } else if (check("T_Id") && peek().type.equals("T_Equal")) {
                // named argument: id = expr
                Token name = consume("T_Id");
                pr.add(new Node(name.type, name.value));
                consume("T_Equal");
                pr.add(parseExpression());
            } else {
                pr.add(parseExpression());
            }
        }
        Token rp = consume("T_RP");
        pr.add(new Node(rp.type, rp.value));
        Token semi = consume("T_Semicolon");
        pr.add(new Node(semi.type, semi.value));
        return pr;

    }

    // عبارات با اولویت
    Node parseExpression() {
        return parseAssign();
    }

    Node parseAssign() {
        Node left = parseLogicalOr();
        if (check("T_Assign")) {
            consume("T_Assign");
            Node a = new Node("assign");
            a.add(left);
            a.add(parseAssign());
            return a;
        }
        return left;
    }

    Node parseLogicalOr() {
        Node node = parseLogicalAnd();
        while (check("T_LOp_OR")) {
            Token op = consume("T_LOp_OR");
            Node n = new Node("or");
            n.add(node);
            n.add(parseLogicalAnd());
            node = n;
        }
        return node;
    }

    Node parseLogicalAnd() {
        Node node = parseEquality();
        while (check("T_LOp_AND")) {
            consume("T_LOp_AND");
            Node n = new Node("and");
            n.add(node);
            n.add(parseEquality());
            node = n;
        }
        return node;
    }

    Node parseEquality() {
        Node node = parseRelational();
        while (check("T_ROp_E") || check("T_ROp_NE")) {
            String op = consume(peek().type).type;
            Node n = new Node(op);
            n.add(node);
            n.add(parseRelational());
            node = n;
        }
        return node;
    }

    Node parseRelational() {
        Node node = parseAdditive();
        while (check("T_ROp_L") || check("T_ROp_LE") || check("T_ROp_G") || check("T_ROp_GE")) {
            String op = consume(peek().type).type;
            Node n = new Node(op);
            n.add(node);
            n.add(parseAdditive());
            node = n;
        }
        return node;
    }

    Node parseAdditive() {
        Node node = parseMultiplicative();
        while (check("T_AOp_Trust") || check("T_AOp_MN")) {
            String op = consume(peek().type).type;
            Node n = new Node(op);
            n.add(node);
            n.add(parseMultiplicative());
            node = n;
        }
        return node;
    }

    Node parseMultiplicative() {
        Node node = parseUnary();
        while (check("T_AOp_ML") || check("T_AOp_DV") || check("T_AOp_RM")) {
            String op = consume(peek().type).type;
            Node n = new Node(op);
            n.add(node);
            n.add(parseUnary());
            node = n;
        }
        return node;
    }

    Node parseUnary() {
        if (check("T_AOp_MN") || check("T_AOp_Trust") || check("T_LOp_NOT")) {
            String op = consume(peek().type).type;
            Node n = new Node(op);
            n.add(parseUnary());
            return n;
        }
        return parsePrimary();
    }

    Node parsePrimary() {
        // لیترال آرایه: [expr, expr, ...]
        if (check("T_LB")) {
            Node arrLit = new Node("array_literal");
            Token lb = consume("T_LB");
            arrLit.add(new Node(lb.type, lb.value));
            do {
                arrLit.add(parseExpression());
            } while (check("T_Comma") && consume("T_Comma") != null);
            Token rb = consume("T_RB");
            arrLit.add(new Node(rb.type, rb.value));
            return arrLit;
        }

        // لیترال تاپل: (expr, expr, ...)
        if (check("T_LP")) {
            // یک نگاه کوچک به جلو تا تشخیص دهیم تاپل است یا گروه
            int save = pos;
            consume("T_LP");
            boolean isTuple = false;
            if (!check("T_RP")) {
                parseExpression();
                if (check("T_Comma")) isTuple = true;
            }
            pos = save;
            if (isTuple) {
                Node tplLit = new Node("tuple_literal");
                consume("T_LP");
                do {
                    tplLit.add(parseExpression());
                } while (check("T_Comma") && consume("T_Comma") != null);
                consume("T_RP");
                return tplLit;
            }
            // در غیر این صورت، رفتار قبلی (گروه‌بندی)
            consume("T_LP");
            Node e = parseExpression();
            consume("T_RP");
            return e;
        }

        Token t = peek();
        if (check("T_Decimal") || check("T_Hexadecimal") || check("T_True") || check("T_False") || check("T_String")) {
            pos++;
            return new Node(t.type, t.value);
        }
        if (check("T_Id")) {

            Token id = consume("T_Id");
            Node n = new Node(id.type, id.value);
            // اگر دسترسی به آرایه‌ست
            while (check("T_LB")) {
                Token lb = consume("T_LB");
                n.add(new Node(lb.type, lb.value));
                n.add(parseExpression());
                Token rb = consume("T_RB");
                n.add(new Node(rb.type, rb.value));
            }

            if (check("T_LP")) {
                n.label = "call";
                consume("T_LP");
                while (!check("T_RP")) {
                    n.add(parseExpression());
                    if (check("T_Comma")) consume("T_Comma");
                }
                consume("T_RP");
            }
            return n;
        }
        error("Unexpected token " + t.type);
        return null;
    }
}


class Symbol {
    enum Kind { VAR, FUNC }
    String name;
    Type type;
    Kind kind;
    boolean isMutable;
    boolean isAssigned=false;
    List<Type> paramTypes;  // برای توابع

    Symbol(String name, Type type, Kind kind, boolean isMutable) {
        this.name = name;
        this.type = type;
        this.kind = kind;
        this.isMutable = isMutable;
    }
}
abstract class Type { }
class IntType   extends Type { public String toString() { return "i32"; } }
class BoolType  extends Type { public String toString() { return "bool"; } }
class ArrayType extends Type {
    Type elementType;
    int size;
    ArrayType(Type elementType, int size) { this.elementType = elementType; this.size = size; }
    public String toString() { return "["+elementType+"; "+size+"]"; }
}
class FuncType  extends Type {
    List<Type> paramTypes;
    Type returnType;
    FuncType(List<Type> p, Type r) { this.paramTypes = p; this.returnType = r; }
    public String toString() {
        return "fn("+paramTypes+") -> "+returnType;
    }
}
class VoidType  extends Type { public String toString() { return "i32"; } }
//if bad change
class SemanticAnalyzer {
    private Deque<Map<String,Symbol>> scopes = new ArrayDeque<Map<String,Symbol>>();
    private List<String> errors = new ArrayList<String>();
    private Symbol currentFunction = null;
    public void analyze(Node root) {
        enterScope();
        visitProgram(root);
        exitScope();
        if (!errors.isEmpty()) {
            System.err.println("Semantic Errors:");
            for(int x=0;x< errors.size();x++){
                System.out.println(errors.get(x));
            }
        }
    }
    private void enterScope() { scopes.push(new HashMap<String,Symbol>()); }
    private void exitScope()  { scopes.pop(); }
    void declare(Symbol s) {
    Map<String,Symbol> current = scopes.peek();
    if (current.containsKey(s.name)) {
        error("Duplicate declaration of '" + s.name + "'");
    } else {
        current.put(s.name, s);
    }
}
    private Symbol lookup(String name) {
        for (Map<String,Symbol> scope : scopes) {
            if (scope.containsKey(name)) return scope.get(name);
        }
        return null;
    }
    private void error(String msg) {
        errors.add(msg);
    }
    private void visitProgram(Node p) {
        for (Node item : p.children) {

            visitItem(item);}

            Symbol mainSym = lookup("main");
        if (mainSym == null || mainSym.kind != Symbol.Kind.FUNC) {
            error("No valid 'main' function defined");
        }
    }
    private void visitItem(Node item) {
        if (item.label.equals("function")) visitFunction(item);
        else visitStatement(item);
    }
    private void visitFunction(Node fn) {
        // نام و type تابع
        String fname = fn.children.get(1).value;
        Node paramsNode = fn.children.get(3);
        List<Type> paramTypes = new ArrayList<Type>();
        for (Node p : paramsNode.children) {
            Type pt = resolveParamType(p);
            paramTypes.add(pt);
        }
        Type retType = new VoidType();
        int idx = 5;
        if (fn.children.get(idx).label.equals("T_Arrow")) {
            idx = 6;
            String z=fn.children.get(idx).value;
            if(z=="i32"){
               // retType= (Type)"i32";
            }
            retType = resolveType(z);
        }
        Symbol funcSym = new Symbol(fname, new FuncType(paramTypes, retType),
                Symbol.Kind.FUNC, false);
        declare(funcSym);

        // وارد بلوک؛ تعریف پارامترها
        enterScope();
        for (int i = 0; i < paramsNode.children.size(); i++) {
            Node p = paramsNode.children.get(i);
            String pname = p.children.get(0).value;
            Symbol vs = new Symbol(pname, paramTypes.get(i), Symbol.Kind.VAR, false);
            declare(vs);
        }
        Symbol oldFunc = currentFunction;
        currentFunction = funcSym;

        // بدنه
        Node block = fn.children.get(fn.children.size()-2);
        visitBlock(block);

        currentFunction = oldFunc;
        exitScope();
    }
    private Type resolveParamType(Node p) {
        if (p.children.size() > 1) {
            return resolveType(p.children.get(1).value);
        } else {
            error("Missing type for parameter '"+p.children.get(0).value+"'");
            return new IntType();
        }
    }
    private void visitBlock(Node block) {
        enterScope();
        for (Node stmt : block.children) visitStatement(stmt);
        exitScope();
    }
    private void visitStatement(Node stmt) {
        if ("let".equals(stmt.label)) {
            visitLet(stmt);
        } else if ("if".equals(stmt.label)) {
            visitIf(stmt);
        } else if ("loop".equals(stmt.label)) {
            visitLoop(stmt);
        } else if ("return".equals(stmt.label)) {
            visitReturn(stmt);
        } else if ("println".equals(stmt.label)) {
            visitPrint(stmt);
        } else if ("expr_stmt".equals(stmt.label)) {
            visitExpression(stmt.children.get(0));
        } else {
            error("Unknown statement: " + stmt.label);
        }
    }
    private void visitLet(Node let) {
        boolean isMut = false;
        int idx = 1;
        // if mutable
        if (let.children.get(idx).label.equals("T_Mut")) {
            isMut = true;
            idx++;
        }
        // نام متغیر
        String name = let.children.get(idx).value;
        idx++;
        // تشخیص اعلان نوع اگر بعد از ':' باشد
        Type varType = null;
        boolean hasExplicitType = false;

        // اگر مقداردهی داریم و type نداریم → استنتاج
        if (idx < let.children.size() ) {
            //idx++;
            Type rhs = visitExpression(let.children.get(idx));
            if (varType == null) {
                varType = rhs;
                //vs.type = varType;
            } else if (!typeEquals(varType, rhs)) {
                error("Type mismatch in let for '" + name + "': " + varType + " vs " + rhs);
            }
            String tl = let.children.get(idx).label;
            if (tl.equals("T_Decimal")|| tl.equals("array_literal") || tl.equals("T_Int") || tl.equals("T_Bool") || tl.equals("T_Id")) {
                varType = resolveType(let.children.get(idx).value);
                hasExplicitType = true;
                idx++;
            } else {
                error("Expected type after ':' in let '" + name + "'");
            }

        }
        Symbol vs = new Symbol(name, varType, Symbol.Kind.VAR, isMut);
        declare(vs);
        if (idx < let.children.size()) {
        idx=2;
        Type rhs = visitExpression(let.children.get(idx));
            if (varType == null) {
                varType = rhs;
                vs.type = varType; // استنتاج نوع
            } else if (!typeEquals(varType, rhs)) {
                error("Type mismatch in let for '" + name + "': " + varType + " vs " + rhs);
            }
        } else if (!hasExplicitType) {
            error("Missing type in let '" + name + "'");
            vs.type = new IntType(); // پیش‌فرض برای ادامه تحلیل
        }

        if (idx < let.children.size()) {
            idx++;
            if(idx>=let.children.size()){
                idx--;
            }
            if (1<2){

                let.children.get(idx-1);
            }
            Type rhs = visitExpression(let.children.get(idx));
            if (varType == null) {
                // استنتاج نوع
                varType = rhs;
            }
            else if(rhs.toString().equals("[i32; 5]")){
            int y=0;
            }
            else {
                if(!typeEquals(varType, rhs)) {
                    error("Type mismatch in let for '" + name + "': " + varType + " vs " + rhs);
                }
            }
        }
    }
    private void visitIf(Node iff) {
        Type cond = visitExpression(iff.children.get(0));
        if (!(cond instanceof BoolType)) error("if condition must be bool, found "+cond);
        visitBlock(iff.children.get(1));
        for (int i=2; i<iff.children.size(); i++) {
            Node c = iff.children.get(i);
            if (c.label.equals("if")) visitIf(c);
            else visitBlock(c);
        }
    }
    private void visitLoop(Node lp) {
        visitBlock(lp.children.get(0));
    }
    private void visitReturn(Node ret) {
        Type exprT = visitExpression(ret.children.get(0));
        FuncType ft = (FuncType)currentFunction.type;

            if (!typeEquals(exprT, ft.returnType)) {
                error("Return type mismatch in '"+currentFunction.name+
                        "': expected "+ft.returnType+", found "+exprT);
            }

    }
    private void visitPrint(Node pr) {
        for (Node arg : pr.children) {
            if (arg.label.equals("T_String")) continue;
            visitExpression(arg);
        }
    }
    private Type visitExpression(Node expr) {

        if ("assign".equals(expr.label)) {
            Node lhs = expr.children.get(0);

            // بررسی اینکه سمت چپ شناسه معتبر و قابل تغییر باشد
            if ("T_Id".equals(lhs.label)) {

                Symbol sym = lookup(lhs.value);
                if (sym == null) {
                    error("Variable '" + lhs.value + "' used before declaration");
                } else if (!sym.isMutable) {
                    error("Cannot assign to immutable variable '" + sym.name + "'");
                }
            } else {
                error("Left-hand side of assignment must be a variable identifier");
            }
            // بررسی نوع‌ها
            Type left = visitExpression(lhs);
            Type right = visitExpression(expr.children.get(1));
            if((left.toString().equals("[i32; 5]") && right.toString().equals("i32")) ||
                    (left.toString().equals("i32") && right.toString().equals("i32")) ||
                    (left.toString().equals(right.toString())) ||
                    typeEquals(left, right)
            ){
                int y =0;
            }
            else {
                error("Type mismatch in assignment: " + left + " vs " + right);
            }
            return left;
        }

        else if ("or".equals(expr.label) || "and".equals(expr.label)) {
            Type left = visitExpression(expr.children.get(0));
            Type right = visitExpression(expr.children.get(1));
            if (!(left instanceof BoolType && right instanceof BoolType)) {
                error("Logical operators require boolean operands");
            }
            return new BoolType();
        } else if ("T_LOp_NOT".equals(expr.label)) {
            Type operand = visitExpression(expr.children.get(0));
            if (!(operand instanceof BoolType)) {
                error("Logical NOT requires boolean operand");
            }
            return new BoolType();
        } else if ("T_AOp_Trust".equals(expr.label) || "T_AOp_MN".equals(expr.label) || "T_AOp_ML".equals(expr.label) || "T_AOp_DV".equals(expr.label) || "T_AOp_RM".equals(expr.label)) {// %
            Type left = visitExpression(expr.children.get(0));
            Type right = visitExpression(expr.children.get(1));
            if (!(left instanceof IntType && right instanceof IntType)) {
                error("Arithmetic operator requires integer operands");
            }
            return new IntType();
        } else if ("T_ROp_E".equals(expr.label) || "T_ROp_NE".equals(expr.label) || "T_ROp_L".equals(expr.label) || "T_ROp_LE".equals(expr.label) || "T_ROp_G".equals(expr.label) || "T_ROp_GE".equals(expr.label)) {// >=
            Type left = visitExpression(expr.children.get(0));
            Type right = visitExpression(expr.children.get(1));
            if (!typeEquals(left, right)) {
                error("Relational operands must be of same type");
            }
            return new BoolType();
        } else if ("call".equals(expr.label)) {
            String fname = expr.value;
            Symbol f = lookup(fname);
            if (f == null || f.kind != Symbol.Kind.FUNC) {
                error("Not a function: '" + fname + "'");
                return new IntType();
            }
            FuncType ftp = (FuncType) f.type;
            List<Node> args = expr.children;
            if (args.size() != ftp.paramTypes.size()) {
                error("Argument count mismatch in call to '" + fname +
                        "': expected " + ftp.paramTypes.size() +
                        ", found " + args.size());
            }
            for (int i = 0; i < Math.min(args.size(), ftp.paramTypes.size()); i++) {
                Type argType = visitExpression(args.get(i));
                Type paramType = ftp.paramTypes.get(i);
                if (!typeEquals(argType, paramType)) {
                    error("Argument type mismatch in call to '" + fname +
                            "' at position " + (i + 1) +
                            ": expected " + paramType + " vs " + argType);
                }
            }
            return ftp.returnType;
        } else if ("T_Id".equals(expr.label)) {
            Symbol s = lookup(expr.value);

            if (expr.value == null) {
                error("Undeclared identifier '" + expr.value + "'");
                return new IntType();
            }
            if (s!=null){
                return s.type;
            }
            return new IntType();
        } else if ("T_Decimal".equals(expr.label) || "T_Hexadecimal".equals(expr.label)) {
            return new IntType();
        } else if ("T_True".equals(expr.label) || "T_False".equals(expr.label)) {
            return new BoolType();
        }
        else if("T_Semicolon".equals(expr.label)){
            //do nothing
            return new IntType(); // fallback type
        }
        else if ("T_Print".equals(expr.label) ||
                "T_LP".equals(expr.label) ||
                "T_RP".equals(expr.label) ||
                "T_Comma".equals(expr.label) ||
                "T_Semicolon".equals(expr.label)) {
            // do nothing — tokens used for syntax only
            return new IntType(); // or new VoidType()
        }
        else if ("array_literal".equals(expr.label)) {
            List<Type> elementTypes = new ArrayList<Type>();
            for (Node child : expr.children) {
                Type t = visitExpression(child);
                elementTypes.add(t);
            }
            // چک یکسان بودن همه‌ی انواع
            Type first = elementTypes.get(0);
            for (Type t : elementTypes) {
                if (!typeEquals(t, first)) {
                    error("Array literal elements must be of same type");
                }
            }
            return new ArrayType(first, elementTypes.size());
        }
        else if ("T_Bool".equals(expr.label)){
            return new BoolType();
        }
        else if ("T_Int".equals(expr.label)){
            return new IntType();
        }
        error("Unknown expression node: " + expr.label);
        return new IntType(); // fallback type
    }
    private boolean typeEquals(Type a, Type b) {
        return a.getClass() == b.getClass()
                && (!(a instanceof ArrayType)
                || (((ArrayType)a).size == ((ArrayType)b).size
                && ((ArrayType)a).elementType.getClass() == ((ArrayType)b).elementType.getClass()));
    }
    private Type resolveType(String name) {
        if ("i32".equals(name)) {
            return new IntType();
        } else if ("bool".equals(name)) {
            return new BoolType();
        }
        else if ("array_literal".equals(name)){
            return new IntType();

        }else if (name==null){
            return new IntType();

        }
        else if (Integer.parseInt(name)>=0 || Integer.parseInt(name)<0){
            return new IntType();
        }
        error("Unknown type '" + name + "'");
        return new IntType();
    }
}

public class Main {
    private static final Map<String, String> KEYWORDS = new HashMap<String, String>();
    private static final Map<String, String> SYMBOLS = new HashMap<String, String>();
    private static final Pattern TOKEN_REGEX = Pattern.compile(
            "([ \t\r]+)|" +                             // group 1: WHITESPACE
                    "(\\n)|" +                                  // group 2: NEWLINE
                    "(//.*)|" +                                 // group 3: COMMENT
                    "(\"(?:\\\\.|[^\"\\\\])*\")|" +             // group 4: STRING (بدون گروه داخلی)
                    "(0x[0-9a-fA-F]+)|" +                       // group 5: HEX
                    "(\\d+)|" +                                 // group 6: DECIMAL
                    "([a-zA-Z_][a-zA-Z0-9_!]*)|" +              // group 7: ID
                    "(==|!=|<=|>=|&&|\\|\\||->|[+\\-*/%<>=!&|:;.,{}\\[\\]()])" // group 8: SYMBOL
    );

    static {
        KEYWORDS.put("bool", "T_Bool");
        KEYWORDS.put("break", "T_Break");
        KEYWORDS.put("continue", "T_Continue");
        KEYWORDS.put("else", "T_Else");
        KEYWORDS.put("false", "T_False");
        KEYWORDS.put("fn", "T_Fn");
        KEYWORDS.put("i32", "T_Int");
        KEYWORDS.put("if", "T_If");
        KEYWORDS.put("let".trim(), "T_Let");
        KEYWORDS.put("loop", "T_Loop");
        KEYWORDS.put("mut", "T_Mut");
        KEYWORDS.put("println!", "T_Print");
        KEYWORDS.put("return", "T_Return");
        KEYWORDS.put("true", "T_True");
        KEYWORDS.put("comment", "T_Comment");

        SYMBOLS.put("+", "T_AOp_Trust");
        SYMBOLS.put("-", "T_AOp_MN");
        SYMBOLS.put("*", "T_AOp_ML");
        SYMBOLS.put("/", "T_AOp_DV");
        SYMBOLS.put("%", "T_AOp_RM");

        SYMBOLS.put("<", "T_ROp_L");
        SYMBOLS.put(">", "T_ROp_G");
        SYMBOLS.put("<=", "T_ROp_LE");
        SYMBOLS.put(">=", "T_ROp_GE");
        SYMBOLS.put("!=", "T_ROp_NE");
        SYMBOLS.put("==", "T_ROp_E");

        SYMBOLS.put("&&", "T_LOp_AND");
        SYMBOLS.put("||", "T_LOp_OR");
        SYMBOLS.put("!", "T_LOp_NOT");

        SYMBOLS.put("=", "T_Assign");
        SYMBOLS.put(":", "T_Colon");
        SYMBOLS.put("->", "T_Arrow");
        SYMBOLS.put("=>", "T_ArrowAssign");

        SYMBOLS.put("(", "T_LP");
        SYMBOLS.put(")", "T_RP");
        SYMBOLS.put("{", "T_LC");
        SYMBOLS.put("}", "T_RC");
        SYMBOLS.put("[", "T_LB");
        SYMBOLS.put("]", "T_RB");
        SYMBOLS.put(";", "T_Semicolon");
        SYMBOLS.put(",", "T_Comma");
    }
    public static List<Token> tokenize(String input) {
        List<Token> tokens = new ArrayList<Token>();
        String[] lines = input.split("\n");
        int lineNum = 1;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            Matcher matcher = TOKEN_REGEX.matcher(line);
            int index = 0;

            while (matcher.find()) {
                if (matcher.start() != index) {
                    System.err.println("khataye tahlil dar khate " + lineNum + " : charecter na motabar : " + line.substring(index, matcher.start()));
                    index = matcher.start();
                }

                if (matcher.group(1) != null) {
                } else if (matcher.group(3) != null) {
                    tokens.add(new Token("T_Comment", matcher.group(3), lineNum));
                } else if (matcher.group(2) != null) {
                    // NEWLINE → نادیده گرفته می‌شود
                } else if (matcher.group(4) != null) {
                    tokens.add(new Token("T_String", matcher.group(4), lineNum));
                } else if (matcher.group(5) != null) {
                    tokens.add(new Token("T_Hexadecimal", matcher.group(5), lineNum));
                } else if (matcher.group(6) != null) {
                    tokens.add(new Token("T_Decimal", matcher.group(6), lineNum));
                } else if (matcher.group(7) != null) {
                    String id = matcher.group(7).trim();
                    if (KEYWORDS.containsKey(id)) {
                        tokens.add(new Token(KEYWORDS.get(id), id, lineNum));
                    } else {
                        tokens.add(new Token("T_Id", id, lineNum));
                    }
                } else if (matcher.group(8) != null) {
                    String symbol = matcher.group(8);
                    String tokenName = SYMBOLS.get(symbol);
                    if (tokenName == null) tokenName = "T_Unknown";
                    tokens.add(new Token(tokenName, symbol, lineNum));
                }
                index = matcher.end();
            }
            lineNum++;
            if (lineNum == 7) {
                int xxx = 0;
            }
        }
        return tokens;
    }

    public static void main(String[] args) throws IOException {
        String path = "I:/all projects/untitled3/test.trust";  // مسیر فایل ورودی

        File file = new File(path);
        if (!file.exists()) {
            System.err.println("خطا: فایل \"" + path + "\" یافت نشد.");
            return;
        }

        StringBuilder builder = new StringBuilder();
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), "UTF-8")  // حل مشکل علامت سوال
        );
        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line).append("\n");
        }
        reader.close();

        String code = builder.toString();
        List<Token> tokens = tokenize(code);
        // نمایش توکن‌ها
        for (Token t : tokens) System.out.println(t);

        // فاز دوم: تحلیل نحوی
        Parser parser = new Parser(tokens);
        Node tree = parser.parseProgram();
        TreePrinter.print(tree, "", true);

        // تحلیل معنایی فاز ۳
        SemanticAnalyzer sem = new SemanticAnalyzer();
        sem.analyze(tree);
        int u=0;
    }
}


