#include <stdio.h>
#include <stdbool.h>

int x = 5;

bool b = true;

int incr(int a) {
    return (a + 1);
}


int main() {
int y = 10;

printf(""Trust is good"");

if(y == 10){
}


return 0;
}



